<?php if ( $pagination = gridlove_numeric_pagination( __gridlove( 'previous_posts' ), __gridlove( 'next_posts' ) ) ) : ?>
	<div data-s1search="pagination"></div>
<?php endif; ?>